﻿Imports System.Web
Imports System.Web.Services
Imports System.IO

Public Class Handler
    Implements System.Web.IHttpHandler, IReadOnlySessionState

    Private RootFolder As String

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        Try
            RootFolder = ConfigurationManager.AppSettings("URLRacineDocs")

            Select Case context.Request.HttpMethod
                Case "HEAD"
                Case "GET"
                    If GivenFilename(context) Then
                        DeliverFile(context)
                    Else
                        DeliverFileList(context)
                    End If
                Case "POST"
                    ' ajax calls POST, but it can be a "DELETE" if there is a QueryString on the context
                    If GivenFilename(context) Then
                        DeleteFile(context)
                    Else
                        Uploadfile(context)
                    End If
                    Return

                Case "PUT"
                Case "DELETE"
                    DeleteFile(context)
                    Return

                Case "OPTIONS"
                Case Else
                    context.Response.ClearHeaders()
                    context.Response.StatusCode = 405
                    Return

            End Select

        Catch ex As Exception
            Throw
        End Try

    End Sub

    Private Function GetFolderSize(ByVal DirPath As String) As Long
        'A votre guise , il y a plein de façon de faire
        Return 0
    End Function

    Private Sub Uploadfile(ByVal context As HttpContext)

        context.Response.ContentType = "text/plain"
        Dim r As New Generic.LinkedList(Of ViewDataUploadFilesResult)
        Dim js As New Script.Serialization.JavaScriptSerializer

        If context.Request.Files.Count >= 1 Then

            Dim FileName As String = String.Empty
            Dim hpf As HttpPostedFile = Nothing
            Dim Range = context.Request.Headers.GetValues("Content-Range")

            'For i = 0 To context.Request.Files.Count - 1
            hpf = context.Request.Files.Item(0) 'i

            If Web.HttpContext.Current.Request.Browser.Browser = "IE" Then
                Dim files As String() = hpf.FileName.Split(CChar("\\"))
                FileName = files(files.Length - 1)
            Else
                FileName = Path.GetFileName(hpf.FileName)
            End If
            Dim savedFileName As String = RootFolder & FileName

            Try
                'Fichier envoyé en 1 seul bloc
                'Vérif taille : sinon chunck
                If Range Is Nothing Then

                    If hpf.ContentLength <= CDbl(System.Configuration.ConfigurationManager.AppSettings.Item("TailleMaxByFile")) Then

                        If CDbl(hpf.ContentLength + CDbl(GetFolderSize(RootFolder))) <= System.Configuration.ConfigurationManager.AppSettings.Item("TailleMax") Then
                            hpf.SaveAs(savedFileName)
                            r.AddLast(New ViewDataUploadFilesResult(FileName, hpf.ContentLength, hpf.ContentType, savedFileName))
                        Else
                            r.AddLast(New ViewDataUploadFilesResult(FileName, hpf.ContentLength, hpf.ContentType, savedFileName, "Taille globale de chargement atteinte"))
                        End If

                    Else
                        r.AddLast(New ViewDataUploadFilesResult(FileName, hpf.ContentLength, hpf.ContentType, savedFileName, "Fichier trop volumineux"))
                    End If

                    Else

                        Using fs = New IO.FileStream(savedFileName, IO.FileMode.Append)

                            Dim PartFromRange As String() = Range(0).Split({" ", "-", "/"}, StringSplitOptions.RemoveEmptyEntries)
                            Dim Length As Long = CLng(PartFromRange(3))
                            Dim UploadedSize As Long = CLng(PartFromRange(1))

                            'Controles de la taille
                            If fs.Length = UploadedSize Then
                                'Ecriture
                                Dim buffer = New Byte(hpf.InputStream.Length - 1) {}
                                fs.Write(buffer, 0, buffer.Length)

                                Dim IsLast As Boolean = (CDbl(PartFromRange(2)) + 1 = Length) '+1 car range commençant à 0
                                If IsLast Then r.AddLast(New ViewDataUploadFilesResult(FileName, Length, hpf.ContentType, savedFileName))
                            Else
                                r.AddLast(New ViewDataUploadFilesResult(FileName, Length, hpf.ContentType, savedFileName, "Erreur lors du transfert"))
                            End If

                        End Using

                    End If

                'Next

            Catch ex As Exception
                r.AddLast(New ViewDataUploadFilesResult(FileName, hpf.ContentLength, hpf.ContentType, savedFileName, ex.Message))
            End Try

        Else
            r.AddLast(New ViewDataUploadFilesResult(String.Empty, 0, Nothing, String.Empty, "Pas de fichier transmis!"))
        End If

        Dim uploadedFiles = New With {Key .files = r.ToArray}
        Dim jsonObj = js.Serialize(uploadedFiles)
        context.Response.Write(jsonObj.ToString)

    End Sub

    Private Sub DeleteFile(ByVal context As HttpContext)
        Try
            Dim r As New Generic.LinkedList(Of ViewDataUploadFilesResult)
            Dim js As New Script.Serialization.JavaScriptSerializer

            Dim path = RootFolder
            Dim file = context.Request("f")
            path &= file
            path = HttpUtility.UrlDecode(path)
            If System.IO.File.Exists(path) Then
                Dim info As System.IO.FileInfo = My.Computer.FileSystem.GetFileInfo(path)
                r.AddLast(New ViewDataUploadFilesResult(info.Name, info.Length, "", ""))
                System.IO.File.Delete(path)
            Else 'Suppression fichier en erreur
                r.AddLast(New ViewDataUploadFilesResult(file, 0, "", ""))
            End If

            Dim uploadedFiles = New With {Key .files = r.ToArray}
            Dim jsonObj = js.Serialize(uploadedFiles)
            context.Response.Write(jsonObj.ToString)

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Sub DeliverFileList(ByVal context As HttpContext)

        If Not System.IO.Directory.Exists(RootFolder) Then System.IO.Directory.CreateDirectory(RootFolder)

        Dim r As New Generic.LinkedList(Of ViewDataUploadFilesResult)
        For Each f In My.Computer.FileSystem.GetFiles(RootFolder)
            Dim info As System.IO.FileInfo = My.Computer.FileSystem.GetFileInfo(f)
            r.AddLast(New ViewDataUploadFilesResult(info.Name, info.Length, "", ""))
        Next

        Dim uploadedFiles = New With {Key .files = r.ToArray}
        Dim js As New Script.Serialization.JavaScriptSerializer
        Dim jsonObj = js.Serialize(uploadedFiles)

        context.Response.Write(jsonObj.ToString)
    End Sub

    Public ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

#Region "Generic helpers"

    Private Sub CheckPath(ByRef serverPath As String)
        Dim initPath As String = String.Empty
        Dim tempPath As String = String.Empty
        Dim folders As String()

        Try

            folders = serverPath.Split(CChar("\\"))

            ' Save file to a server
            If serverPath.Contains("\\") Then
                initPath = "\\"
            Else
                ' Save file to a local folders
            End If

            For i As Integer = 0 To folders.Length - 1
                If tempPath.Trim = String.Empty And _
                folders(i) <> String.Empty Then
                    tempPath = initPath & folders(i)
                ElseIf tempPath.Trim <> String.Empty And _
                folders(i).Trim <> String.Empty Then
                    tempPath = tempPath & "\" & folders(i)

                    ' Doesn't check if it's a network connection
                    If Not tempPath.Contains("\\") And _
                    Not folders(i).Contains("$") Then

                        If Not System.IO.Directory.Exists(tempPath) Then
                            System.IO.Directory.CreateDirectory(tempPath)
                        End If

                    Else
                        If Not System.IO.Directory.Exists(tempPath) Then
                            System.IO.Directory.CreateDirectory(tempPath)
                        End If

                    End If

                End If

            Next

            serverPath = tempPath & "\"

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Private Function GivenFilename(ByVal context As HttpContext) As Boolean
        Try
            Return Not String.IsNullOrEmpty(context.Request("f"))
        Catch ex As Exception
            Throw
        End Try
    End Function

    Private Sub DeliverFile(ByVal context As HttpContext)
        Try
            Dim file = context.Request("f")
            Dim filePath = RootFolder & file

            If System.IO.File.Exists(filePath) Then
                context.Response.AddHeader("Content-Disposition", "attachment; filename=" + HttpContext.Current.Server.UrlPathEncode(file))
                context.Response.ContentType = "application/octet-stream"
                context.Response.ClearContent()
                context.Response.WriteFile(filePath)
            Else
                context.Response.StatusCode = 404
            End If

        Catch ex As Exception
            Throw
        End Try
    End Sub

#End Region

End Class

#Region "local Class"

Public Class ViewDataUploadFilesResult

    Public Property name As String
    Public Property size As Integer
    Public Property type As String
    Public Property deleteUrl As String
    Public Property deleteType As String
    Public Property [error] As String
    Public Property url As String

    Sub New()
        Try

        Catch ex As Exception
            Throw
        End Try
    End Sub

    Sub New(ByVal pName As String, ByVal pLength As Integer, ByVal pType As String, ByVal pURL As String)
        Try
            name = pName
            size = pLength
            type = pType
            url = "/Handler.ashx?f=" & HttpContext.Current.Server.UrlEncode(name)
            deleteUrl = "/Handler.ashx?f=" & HttpContext.Current.Server.UrlEncode(name)
            deleteType = "POST"
        Catch ex As Exception
            Throw
        End Try
    End Sub

    Sub New(ByVal pName As String, ByVal pLength As Integer, ByVal pType As String, ByVal pURL As String, ByVal perrorMSG As String)
        Try
            name = pName
            size = pLength
            type = pType
            url = "#"
            deleteUrl = "/Handler.ashx?f=" & HttpContext.Current.Server.UrlEncode(name)
            deleteType = "POST"
            [error] = perrorMSG
        Catch ex As Exception
            Throw
        End Try
    End Sub

End Class

#End Region