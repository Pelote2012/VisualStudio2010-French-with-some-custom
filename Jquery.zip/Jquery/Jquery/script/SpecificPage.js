﻿$(function () {
    $("#btnValider").button();
    $(document).on("click", "#btnValider", function () {
        alert("Sent");
    });
});

function CheckEnvoyer(fileupload) {

    var AttenteChargement = fileupload.filesContainer.children('.template-upload').not('.Err').length;
    var Charge = fileupload.filesContainer.children('.template-download').not('.Err').length;

    if ((AttenteChargement > 0) || (Charge < 1)) {
        $("#btnValider").attr("disabled", "disabled");
        $("#btnValider").attr("aria-disabled", true);
    }
    else {
        $("#btnValider").removeAttr("disabled");
        $("#btnValider").attr("aria-disabled", false);
    }
}

function getPictpath(name) {
    if (name != undefined) {
        var filepart = name.toLowerCase().split(".");
        if (filepart.length > 0) {
            switch (filepart[filepart.length - 1]) {
                case 'doc':
                case 'docx':
                case 'rtf':
                    return '/Images/content-types/Word.png';
                    break;
                case "xls":
                case "xlsx":
                case "csv":
                    return '/Images/content-types/Excel.png';
                    break;
                case "ppt":
                case "pps":
                case "pptx":
                    return '/Images/content-types/PowerPoint.png';
                    break;
                case "pdf":
                    return '/Images/content-types/PDF.png';
                    break;
                case "jpg":
                case "png":
                case "gif":
                case "jpeg":
                case "tif":
                case "tiff":
                case "bmp":
                    return '/Images/content-types/Image.png';
                    break;
                case "mp3":
                    return '/Images/content-types/mp3.png';
                    break;
                case "mp4":
                case "wmv":
                case "avi":
                case "mov":
                    return '/Images/content-types/Multimedia.png';
                    break;
                case "txt":
                    return '/Images/content-types/Text.png';
                    break;
                case "zip":
                case "rar":
                    return '/Images/content-types/Zip.png';
                    break;
                case "exe":
                    return '/Images/content-types/exe.png';
                    break;
                case "iso":
                    return '/Images/content-types/iso.png';
                    break;
                default:
                    return '/Images/content-types/File.png';
                    break;
            };
        }
        else {
            return '/Images/content-types/File.png';
        }
    }
    else {
        return '/Images/content-types/File.png';
    }
};