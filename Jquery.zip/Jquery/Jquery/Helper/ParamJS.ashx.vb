﻿Imports System.Web
Imports System.Web.Services

Public Class ParamJS
    Implements System.Web.IHttpHandler

    Private Class serialClass
        Property val As String
        Property EstString As Boolean

        Sub New(ByVal pval As String, ByVal pEstChaine As Boolean)
            val = pval
            EstString = pEstChaine
        End Sub
    End Class
    Private Constants As New Dictionary(Of String, serialClass)

    Public Sub New()
        Constants.Add("SizMaxFile", New serialClass(System.Configuration.ConfigurationManager.AppSettings.Item("TailleMaxByFile"), False))
        Constants.Add("SizMaxUP", New serialClass(System.Configuration.ConfigurationManager.AppSettings.Item("TailleMax"), False))
        Constants.Add("NumberMaxFiles", New serialClass(System.Configuration.ConfigurationManager.AppSettings.Item("NbMaxFiles"), False))
        Constants.Add("AutorizedFiles", New serialClass(System.Configuration.ConfigurationManager.AppSettings.Item("AutorizedFiles"), False))
        Constants.Add("SizeChunk", New serialClass(System.Configuration.ConfigurationManager.AppSettings.Item("SizeChunk"), False))
    End Sub

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest

        context.Response.ContentType = "application/javascript"
        For Each item In Constants
            context.Response.Output.WriteLine("{0} = {1};", item.Key, If(item.Value.EstString, "'" & item.Value.val & "'", item.Value.val))
        Next

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class